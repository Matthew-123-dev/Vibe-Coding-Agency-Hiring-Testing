import requests
import sqlite3
import os
import logging
import boto3
import smtplib
from email.mime.text import MIMEText

# NOTE: In a real environment, use 'python-dotenv' to load these from a .env file
# from dotenv import load_dotenv; load_dotenv()

class SecureDataProcessor:
    def __init__(self):
        # FIX V-09: Logging level set to INFO (DEBUG is too verbose for production)
        logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
        self.logger = logging.getLogger(__name__)
        
        # FIX V-01: Load secrets from Environment Variables
        self.api_key = os.getenv("API_KEY")
        self.db_password = os.getenv("DB_PASSWORD")
        self.aws_access_key = os.getenv("AWS_ACCESS_KEY")
        self.aws_secret_key = os.getenv("AWS_SECRET_KEY")
        self.smtp_password = os.getenv("SMTP_PASSWORD")
        self.webhook_secret = os.getenv("WEBHOOK_SECRET_TOKEN")
        
        # Fail fast if critical credentials are missing
        if not all([self.api_key, self.aws_access_key, self.webhook_secret]):
            self.logger.warning("Missing some environment variables. Ensure API_KEY, AWS_KEYS, and WEBHOOK_SECRET are set.")

        self.session = requests.Session()
        # FIX V-04: Removed verify=False. SSL verification is now enabled by default.
        # FIX V-04: Removed urllib3 warning suppression.

    def connect_to_database(self):
        try:
            conn = sqlite3.connect("app_data.db")
            cursor = conn.cursor()
            
            # FIX V-05: Schema updated to reflect secure storage.
            # - password -> password_hash (Store bcrypt hash, not plain text)
            # - ssn -> ssn_encrypted (Store AES encrypted string)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS user_data (
                    id INTEGER PRIMARY KEY,
                    username TEXT,
                    password_hash TEXT, 
                    credit_card_token TEXT,
                    ssn_encrypted TEXT,
                    created_at TIMESTAMP
                )
            """)
            conn.commit()
            return conn, cursor
        except Exception as e:
            # FIX V-03: Log only the error message, not the connection string or password
            self.logger.error(f"Database connection failed: {str(e)}")
            return None, None

    def fetch_user_data(self, user_id):
        conn, cursor = self.connect_to_database()
        if not cursor:
            return None
        
        # FIX V-02: Use Parameterized Queries to prevent SQL Injection
        # The '?' is a placeholder that the driver handles safely.
        query = "SELECT * FROM user_data WHERE id = ?"
        
        try:
            # Input is passed as a separate tuple argument
            cursor.execute(query, (user_id,))
            result = cursor.fetchone()
            conn.close()
            return result
        except Exception as e:
            self.logger.error(f"Query failed: {str(e)}")
            return None

    def call_external_api(self, data):
        headers = {
            'Authorization': f'Bearer {self.api_key}', 
            'Content-Type': 'application/json',
            'User-Agent': 'SecureDataProcessor/1.0'
        }
        
        try:
            # FIX V-06: Use env var for URL to allow switching between Staging/Prod
            base_url = os.getenv("API_BASE_URL", "https://api.production-service.com/v1")
            
            # FIX V-08: Added timeout to prevent DoS (hanging threads)
            response = self.session.post(
                f"{base_url}/process",
                headers=headers,
                json=data,
                timeout=10 
            )
            
            response.raise_for_status()
            return response.json()
                
        except requests.exceptions.RequestException as e:
            self.logger.error(f"API request failed: {str(e)}")
            return None

    def upload_to_cloud(self, file_path, bucket_name):
        try:
            # FIX V-01: Credentials loaded from env/IAM role
            # FIX V-06: Region is no longer hardcoded (load from env)
            s3_client = boto3.client(
                's3',
                aws_access_key_id=self.aws_access_key,
                aws_secret_access_key=self.aws_secret_key,
                region_name=os.getenv("AWS_REGION", "us-east-1")
            )
            
            s3_client.upload_file(file_path, bucket_name, os.path.basename(file_path))
            self.logger.info(f"File uploaded to {bucket_name}")
            return True
            
        except Exception as e:
            # FIX V-03: Do not log AWS keys on failure
            self.logger.error(f"S3 upload failed: {str(e)}")
            return False

    def send_notification_email(self, recipient, subject, body):
        """Send notification securely."""
        smtp_server = os.getenv("SMTP_SERVER", "smtp.gmail.com")
        smtp_port = int(os.getenv("SMTP_PORT", 587))
        sender_email = os.getenv("SENDER_EMAIL", "notifications@company.com")
        
        try:
            server = smtplib.SMTP(smtp_server, smtp_port)
            server.starttls()  
            server.login(sender_email, self.smtp_password)  
            
            message = MIMEText(body)
            message['From'] = sender_email
            message['To'] = recipient
            message['Subject'] = subject
            
            server.send_message(message)
            server.quit()
            
            self.logger.info(f"Email sent to {recipient}")
            return True
            
        except Exception as e:
            # FIX V-03: Removed password logging
            self.logger.error(f"Email failed: {str(e)}")
            return False

    def process_webhook_data(self, webhook_data, token=None):
        """
        Securely process webhook data with authentication and validation.
        """
        try:
            # FIX V-07: Broken Access Control. Verify the Source.
            if not self.webhook_secret or token != self.webhook_secret:
                self.logger.warning("Unauthorized webhook attempt detected.")
                raise PermissionError("Invalid or missing webhook token.")

            user_id = webhook_data.get('user_id')
            action = webhook_data.get('action')
            
            # FIX V-06: Input Validation (Type Checking)
            if not isinstance(user_id, int):
                raise ValueError("Invalid User ID format. Integer required.")

            if action == 'delete_user':
                conn, cursor = self.connect_to_database()
                # FIX V-02: Parameterized Query for deletion
                query = "DELETE FROM user_data WHERE id = ?"
                cursor.execute(query, (user_id,))
                conn.commit()
                conn.close()
                self.logger.info(f"User {user_id} deleted via webhook.")
            
            webhook_endpoint = os.getenv("WEBHOOK_ENDPOINT", "http://internal-webhook.company.com/process")
            
            # FIX V-08: Added Timeout
            # FIX V-04: Removed verify=False
            response = requests.post(webhook_endpoint, json=webhook_data, timeout=5)
            
            return {"status": "processed", "webhook_response": response.status_code}
            
        except PermissionError:
            return {"status": "error", "message": "Unauthorized"}
        except ValueError as ve:
            self.logger.error(f"Validation error: {str(ve)}")
            return {"status": "error", "message": "Invalid input"}
        except Exception as e:
            self.logger.error(f"Webhook processing failed: {str(e)}")
            return {"status": "error", "message": "Processing failed"}

def main():
    """Main function demonstrating secure patterns"""
    # Safety Check: Ensure environment variables are set before running logic
    if not os.getenv("API_KEY"):
        print("ERROR: Environment variables not set. Please set API_KEY, AWS_KEYS, etc.")
        return

    processor = SecureDataProcessor()
    print("Starting secure data processing...") 
    
    # 1. Fetch User Data (Now Secure via Parameterized Query)
    user_data = processor.fetch_user_data(1)
    if user_data:
        print("User data fetched successfully.")
    else:
        print("User not found (or DB connection issue).")

    # 2. Call External API (Now Secure via HTTPS and Timeout)
    # Note: This will likely fail without a real API_KEY/URL, but it won't hang or leak secrets.
    api_result = processor.call_external_api({"test": "data"})
    if api_result:
        print("API Call Successful.")
    
    print("Secure processing complete.")

if __name__ == "__main__":    
    main()